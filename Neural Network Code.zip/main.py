


from direction_driver import direction_driver
from data_organizer import data_organizer

#x,y,z = txtUnpacker(None,0)
#x,y,z = txtUnpacker(None,0)
#head,L,R = data_organizer(x,y,z)
#classify = direction_driver(head,L,len(x))
import numpy as np

from text_sorter import txt_main

def main():
    x, y, z = txt_main()
    x = np.array(x)
    y = np.array(y)
    z = np.array(z)
# x,y,z = txtUnpacker(None,0)
    head,L,R = data_organizer(x,y,z)
    classify = direction_driver(head,L,len(x))
    #classification = {'eye_x': [], 'eye_y': [], 'eye_z': [], 'eye_motion_x': [], 'eye_motion_y':[], 'head_motion_x' :[],'head_motion_y':[]}
    X = np.array([classify['eye_x'],classify['eye_y']])#,classify['eye_motion_x'],classify['eye_motion_y']]
    Y = np.array([classify['head_motion_x'],classify['head_motion_y']])
    print(X)
    print(Y)
    return X,Y
X,y = main()

# Import necessary libraries
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

# Load the Breast Cancer dataset
cancer_data = load_breast_cancer()
#X, y = cancer_data.data, cancer_data.target

X = (X.reshape(-1, 2))
y=(y.reshape(-1, 2))
print(X)
# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
# Create an MLPClassifier model
mlp = MLPClassifier(alpha = 0.000001, hidden_layer_sizes=(62, 62),
					max_iter=1000000, random_state=0)
# Train the model on the training data
mlp.fit(X_train, y_train)

# Make predictions on the test data
y_pred = mlp.predict(X_test)

# Calculate the accuracy of the model
accuracy = accuracy_score(y_test, y_pred)

print(f"Accuracy: {accuracy:.2f}")
